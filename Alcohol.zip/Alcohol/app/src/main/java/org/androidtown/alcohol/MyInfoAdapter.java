package org.androidtown.alcohol;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MyInfoAdapter extends BaseAdapter {
    ArrayList<DrinkInfo> drinkInfos;
    MyInfoAdapter(ArrayList<DrinkInfo> drinkInfos){
        this.drinkInfos=drinkInfos;
    }
    public class ViewHolder{
        TextView type,name,rate;
        //ImageView congestion_img;
    }
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {//viewGroup은 parent//view는 convertview
        ViewHolder viewHolder=new ViewHolder();
        view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.drink_info,viewGroup,false);
        viewHolder.rate=view.findViewById(R.id.rate_info);
        viewHolder.type=view.findViewById(R.id.drink_type);
        viewHolder.name=view.findViewById(R.id.drink_name);
        String rate=drinkInfos.get(i).getRate()+"";
        viewHolder.rate.setText(rate);
        viewHolder.name.setText(drinkInfos.get(i).getDrinkName());
        viewHolder.type.setText(drinkInfos.get(i).getDrinkType());
        return view;
    }

    @Override
    public Object getItem(int i) {
        return drinkInfos.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public int getCount() {
        return drinkInfos.size();
    }
}
